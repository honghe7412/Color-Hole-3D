﻿using UnityEditor;

namespace Watermelon
{
    public abstract class PropertyValidator
    {
        public abstract void ValidateProperty(SerializedProperty property);
    }
}
