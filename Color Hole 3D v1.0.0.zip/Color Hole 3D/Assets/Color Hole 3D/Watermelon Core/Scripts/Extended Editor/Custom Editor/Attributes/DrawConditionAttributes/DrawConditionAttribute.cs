﻿using System;

namespace Watermelon
{
    public class DrawConditionAttribute : ExtendedEditorAttribute
    {

    }
}
