﻿using System;

namespace Watermelon
{
    public class ExtendedEditorAttribute : Attribute
    {
    }
}
