﻿using System;

namespace Watermelon
{
    public abstract class DrawerAttribute : ExtendedEditorAttribute
    {
    }
}