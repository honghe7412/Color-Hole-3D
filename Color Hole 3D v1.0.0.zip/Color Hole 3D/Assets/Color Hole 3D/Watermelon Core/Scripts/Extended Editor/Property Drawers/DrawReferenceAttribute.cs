﻿using System;
using UnityEngine;

namespace Watermelon
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
    public sealed class DrawReferenceAttribute : PropertyAttribute
    {

    }
}