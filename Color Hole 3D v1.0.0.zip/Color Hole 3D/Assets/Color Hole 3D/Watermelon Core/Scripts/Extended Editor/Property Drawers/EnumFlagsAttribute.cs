﻿using UnityEngine;

namespace Watermelon
{
    public class EnumFlagsAttribute : PropertyAttribute
    {
        public EnumFlagsAttribute()
        {

        }
    }
}
