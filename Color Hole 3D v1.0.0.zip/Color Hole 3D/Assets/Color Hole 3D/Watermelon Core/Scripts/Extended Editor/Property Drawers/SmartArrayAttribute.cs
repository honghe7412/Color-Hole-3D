﻿using System;
using UnityEngine;

namespace Watermelon
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
    public class SmartArrayAttribute : PropertyAttribute
    {

    }
}