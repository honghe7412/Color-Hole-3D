﻿namespace Watermelon
{
    public static class ApplicationConsts
    {
        public const string PROJECT_FOLDER = "Color Hole 3D";
    }
}
