﻿namespace Watermelon
{
    public interface IInitialized
    {
        void Init();
    }
}
