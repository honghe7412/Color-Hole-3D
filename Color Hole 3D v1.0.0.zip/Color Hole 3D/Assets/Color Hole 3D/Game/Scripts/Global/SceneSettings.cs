﻿namespace Watermelon
{
    public enum Scenes
    {
        Init,
        Game,
    }
}